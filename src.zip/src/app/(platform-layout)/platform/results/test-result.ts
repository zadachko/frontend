// Re-export TestResult from shared types
export type { TestResult } from '@/types'
