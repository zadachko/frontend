"use client"
import { Flame, Star, Check } from "lucide-react"

const Sidebar = () => {
    // Mock user data
    const userData = {
        name: "Антон Янков",
        level: 111,
        currentXP: 46214,
        xpToNextLevel: 8795,
        streak: 8,
        avatar: "/avatar.png",
    }

    // Mock daily missions
    const dailyMissions = [
        {
            id: 1,
            title: "Реши 5 задачи по математика",
            completed: true,
            progress: 5,
            total: 5,
        },
        {
            id: 2,
            title: "Постигни 80% точност",
            completed: false,
            progress: 65,
            total: 80,
        },
    ]

    const xpProgress = (userData.currentXP / (userData.currentXP + userData.xpToNextLevel)) * 100

    return (
        <div className="hidden md:flex flex-col h-screen w-80 bg-white text-gray-900">
            {/* User Profile Section */}
            <div className="p-8 pt-16 flex-1 flex flex-col justify-start">
                {/* Avatar with Level Badge */}
                <div className="relative mb-6 flex justify-center">
                    <div className="relative">
                        <div className="w-48 h-48 rounded-full border-4 border-gray-200 overflow-hidden bg-gray-100">
                            <img
                                src={userData.avatar || "/placeholder.svg"}
                                alt={userData.name}
                                className="w-full h-full object-cover"
                            />
                        </div>
                        {/* Level Badge */}
                        <div className="absolute -top-3 -right-3 w-15 h-15 bg-gray-800 rounded-full flex items-center justify-center border-2 border-white">
                            <span className="text-xl font-bold text-white">{userData.level}</span>
                        </div>
                        {/* Progress Ring */}
                        <svg className="absolute inset-0 w-48 h-48 -rotate-90" viewBox="0 0 36 36">
                            <path
                                d="M18 2.0845
                                a 15.9155 15.9155 0 0 1 0 31.831
                                a 15.9155 15.9155 0 0 1 0 -31.831"
                                fill="none"
                                stroke="rgba(0,0,0,0.1)"
                                strokeWidth="2"
                            />
                            <path
                                d="M18 2.0845
                                a 15.9155 15.9155 0 0 1 0 31.831
                                a 15.9155 15.9155 0 0 1 0 -31.831"
                                fill="none"
                                stroke="#10b981"
                                strokeWidth="2"
                                strokeDasharray={`${xpProgress}, 100`}
                                strokeLinecap="round"
                            />
                        </svg>
                    </div>
                </div>

                {/* User Name */}
                <h2 className="text-2xl font-bold text-center mb-4">{userData.name}</h2>

                {/* Level and XP Info */}
                <div className="flex items-center justify-center gap-3 mb-3">
                    <div className="flex items-center gap-2 bg-gray-100 px-3 py-2 rounded-full">
                        <div className="w-3 h-3 bg-green-400 rounded-full"></div>
                        <span className="text-sm font-medium">Ниво {userData.level}</span>
                    </div>
                    <div className="flex items-center gap-2 bg-gray-100 px-3 py-2 rounded-full">
                        <Star className="w-4 h-4 text-yellow-500" />
                        <span className="text-sm font-medium">{userData.currentXP.toLocaleString()} XP</span>
                    </div>
                </div>

                {/* XP Progress */}
                <div className="text-center mb-6">
                    <p className="text-sm text-gray-500 mb-1">
                        До ниво {userData.level + 1} остават: {userData.xpToNextLevel.toLocaleString()} XP
                    </p>
                </div>

                {/* Streak */}
                <div className="flex items-center justify-center gap-3 mb-8">
                    <Flame className="w-6 h-6 text-orange-500" />
                    <span className="text-lg font-medium">{userData.streak} day streak</span>
                </div>

                {/* Daily Missions */}
                <div className="bg-gray-100 rounded-lg p-4">
                    <h3 className="text-lg font-medium mb-4 text-center">Дневни мисии</h3>
                    <div className="space-y-3">
                        {dailyMissions.map((mission) => (
                            <div
                                key={mission.id}
                                className={`rounded-lg p-3 border-2 ${mission.completed
                                    ? "bg-green-100 border-green-300"
                                    : "bg-white border-gray-200"
                                    }`}
                            >
                                <div className="flex items-center gap-3">
                                    <div
                                        className={`w-6 h-6 rounded-full flex items-center justify-center ${mission.completed
                                            ? "bg-green-500"
                                            : "bg-gray-300"
                                            }`}
                                    >
                                        {mission.completed ? (
                                            <Check className="w-4 h-4 text-white" />
                                        ) : (
                                            <span className="text-xs font-bold text-white">
                                                {mission.progress}
                                            </span>
                                        )}
                                    </div>
                                    <div className="flex-1">
                                        <p className="text-sm font-medium text-gray-800">{mission.title}</p>
                                        {!mission.completed && (
                                            <p className="text-xs text-gray-500">
                                                {mission.progress}/{mission.total}
                                            </p>
                                        )}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Sidebar
