export interface Activity {
    id: number
    type: string
    title: string
    status: string
    statusType: string
    date: string
    action: string
} 