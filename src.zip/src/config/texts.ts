export const QUESTION_TEXTS = {
	openAnswerPrompt: 'Напишете вашия отговор',
	multipleChoicePrompt: 'Изберете своя отговор:',
};
